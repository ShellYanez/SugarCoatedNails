import { Link } from 'react-router-dom';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer
      style={{
        background: 'hsl(var(--secondary))',
        borderTop: '1px solid hsl(var(--border))',
        padding: '32px',
      }}
    >
      <div
        style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '16px',
        }}
      >
        <Link
          to="/"
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: '18px',
            fontWeight: 400,
            letterSpacing: '0.06em',
            color: 'hsl(var(--primary))',
            textDecoration: 'none',
          }}
        >
          SugarCoated Nails
        </Link>

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '24px',
            flexWrap: 'wrap',
            justifyContent: 'center',
          }}
        >
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: '11px',
              fontWeight: 500,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: 'hsl(var(--muted-foreground))',
              textDecoration: 'none',
              transition: 'color 200ms ease',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--primary))';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--muted-foreground))';
            }}
          >
            Instagram
          </a>
          <span style={{ color: 'hsl(var(--border))', fontSize: '12px' }}>·</span>
          <Link
            to="/booking"
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: '11px',
              fontWeight: 500,
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: 'hsl(var(--muted-foreground))',
              textDecoration: 'none',
              transition: 'color 200ms ease',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--primary))';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--muted-foreground))';
            }}
          >
            Book an Appointment
          </Link>
        </div>

        <p
          style={{
            fontFamily: 'var(--font-sans)',
            fontSize: '12px',
            color: 'hsl(var(--muted-foreground))',
            margin: 0,
          }}
        >
          © {currentYear} SugarCoated Nails. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
