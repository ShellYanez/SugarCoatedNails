import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';

export default function Header() {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [navVisible, setNavVisible] = useState(false);
  const heroRef = useRef<Element | null>(null);

  const navItems = [
    { href: '/portfolio', label: 'Portfolio' },
    { href: '/services', label: 'Services' },
    { href: '/booking', label: 'Booking' },
    { href: '/about', label: 'About' },
  ];

  useEffect(() => {
    // Reveal nav links once hero portrait scrolls past
    const portrait = document.querySelector('.folio-portrait');
    heroRef.current = portrait;

    const onScroll = () => {
      if (!heroRef.current) {
        heroRef.current = document.querySelector('.folio-portrait');
      }
      if (!heroRef.current) {
        setNavVisible(true);
        return;
      }
      const bottom = heroRef.current.getBoundingClientRect().bottom;
      setNavVisible(bottom < 80);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  return (
    <header
      className="sticky top-0 z-50"
      style={{
        background: 'hsl(var(--background))',
        borderBottom: '1px solid hsl(var(--border))',
        boxShadow: '0 2px 12px rgba(155,111,190,0.10)',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          maxWidth: '1200px',
          margin: '0 auto',
          padding: '0 32px',
          height: '72px',
          gap: '40px',
        }}
      >
        {/* Wordmark */}
        <Link
          to="/"
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: '22px',
            fontWeight: 400,
            letterSpacing: '0.06em',
            color: 'hsl(var(--primary))',
            textDecoration: 'none',
            flexShrink: 0,
            lineHeight: 1,
          }}
        >
          SugarCoated Nails
        </Link>

        {/* Desktop nav links — fade in after hero scrolls past */}
        <nav
          className="hidden md:flex"
          aria-label="Primary navigation"
          style={{
            alignItems: 'center',
            gap: '32px',
            flex: 1,
            opacity: navVisible ? 1 : 0,
            transform: navVisible ? 'translateY(0)' : 'translateY(-4px)',
            transition: 'opacity 320ms cubic-bezier(0.25,0.46,0.45,0.94), transform 320ms cubic-bezier(0.25,0.46,0.45,0.94)',
            pointerEvents: navVisible ? 'auto' : 'none',
          }}
        >
          {navItems.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: '12px',
                fontWeight: 500,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: location.pathname === item.href
                  ? 'hsl(var(--primary))'
                  : 'hsl(var(--muted-foreground))',
                textDecoration: 'none',
                paddingBottom: '2px',
                borderBottom: location.pathname === item.href
                  ? '1.5px solid hsl(var(--primary))'
                  : '1.5px solid transparent',
                transition: 'color 200ms ease, border-color 200ms ease',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--primary))';
                (e.currentTarget as HTMLAnchorElement).style.borderBottomColor = 'hsl(var(--primary))';
              }}
              onMouseLeave={(e) => {
                if (location.pathname !== item.href) {
                  (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--muted-foreground))';
                  (e.currentTarget as HTMLAnchorElement).style.borderBottomColor = 'transparent';
                }
              }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Book Now CTA */}
        <div className="hidden md:flex" style={{ flexShrink: 0, marginLeft: 'auto' }}>
          <Link
            to="/booking"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              padding: '10px 24px',
              background: 'hsl(var(--primary))',
              color: 'hsl(var(--primary-foreground))',
              fontFamily: 'var(--font-heading)',
              fontSize: '12px',
              fontWeight: 600,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              textDecoration: 'none',
              borderRadius: '9999px',
              boxShadow: '0 4px 20px rgba(155,111,190,0.20)',
              transition: 'transform 200ms ease, box-shadow 200ms ease, background 200ms ease',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-2px)';
              (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 6px 24px rgba(155,111,190,0.35)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(0)';
              (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 4px 20px rgba(155,111,190,0.20)';
            }}
          >
            Book Now
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden"
          aria-label="Toggle menu"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '40px',
            height: '40px',
            background: 'transparent',
            border: 'none',
            borderRadius: '8px',
            color: 'hsl(var(--primary))',
            cursor: 'pointer',
          }}
        >
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div
          className="md:hidden"
          style={{
            borderTop: '1px solid hsl(var(--border))',
            background: 'hsl(var(--background))',
            padding: '16px 32px 24px',
          }}
        >
          <nav style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            {navItems.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                onClick={() => setIsMobileMenuOpen(false)}
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '14px',
                  fontWeight: 500,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  color: location.pathname === item.href
                    ? 'hsl(var(--primary))'
                    : 'hsl(var(--muted-foreground))',
                  textDecoration: 'none',
                  padding: '12px 0',
                  borderBottom: '1px solid hsl(var(--border))',
                }}
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/booking"
              onClick={() => setIsMobileMenuOpen(false)}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginTop: '16px',
                padding: '12px 24px',
                background: 'hsl(var(--primary))',
                color: 'hsl(var(--primary-foreground))',
                fontFamily: 'var(--font-heading)',
                fontSize: '12px',
                fontWeight: 600,
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                textDecoration: 'none',
                borderRadius: '9999px',
              }}
            >
              Book Now
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
