import { RouteObject } from 'react-router-dom';
import { lazy } from 'react';
import HomePage from './pages/index';
const PortfolioPage = lazy(() => import('./pages/portfolio'));
const ServicesPage = lazy(() => import('./pages/services'));
const BookingPage = lazy(() => import('./pages/booking'));
const AboutPage = lazy(() => import('./pages/about'));
// Eager import so renderToString doesn't hit a Suspense boundary on 404 routes
// and abort to client rendering. The prod 404 page is tiny; the dev-tools
// variant stays lazy because it pulls in dev-only code we don't want in
// production bundles.
import ProdNotFoundPage from './pages/_404';

const NotFoundPage = import.meta.env.DEV
  ? lazy(() => import('../dev-tools/src/PageNotFound'))
  : ProdNotFoundPage;

export const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/portfolio',
    element: <PortfolioPage />,
  },
  {
    path: '/services',
    element: <ServicesPage />,
  },
  {
    path: '/booking',
    element: <BookingPage />,
  },
  {
    path: '/about',
    element: <AboutPage />,
  },
  {
    path: '*',
    element: <NotFoundPage />,
  },
];

// Types for type-safe navigation
export type Path = '/' | '/portfolio' | '/services' | '/booking' | '/about';

export type Params = Record<string, string | undefined>;
