import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { useRef, useState, useCallback } from 'react';

// ─── Types ───────────────────────────────────────────────────────────────────

interface RitualOption {
  id: string;
  name: string;
  duration: string;
  price: string;
}

// ─── Data ────────────────────────────────────────────────────────────────────

const RITUAL_OPTIONS: RitualOption[] = [
{ id: 'gel-manicure', name: 'Gel Manicure', duration: '60 min — chip-free, lasts 2–3 weeks', price: '$55' },
{ id: 'custom-art', name: 'Custom Nail Art', duration: '90 min — fully bespoke, hand-painted', price: 'from $75' },
{ id: 'spa-pedicure', name: 'Spa Pedicure', duration: '75 min — soak, scrub, massage, polish', price: '$65' },
{ id: 'gel-pedicure', name: 'Gel Pedicure', duration: '75 min — gel polish, lasts 3–4 weeks', price: '$75' },
{ id: 'consultation', name: 'Nail Consultation', duration: '30 min — design planning, no service', price: 'Free' }];


const ALL_SLOTS = [
'9:00 am', '9:45 am', '10:30 am', '11:15 am',
'12:00 pm', '2:00 pm', '3:00 pm', '4:00 pm', '4:45 pm'];


// Dates fully blocked (YYYY-MM-DD) — replace with live availability API
const BLOCKED_DATES: string[] = [];

// Slots booked on specific dates — replace with live data
const BOOKED_SLOTS: Record<string, string[]> = {};

const MONTHS = [
'January', 'February', 'March', 'April', 'May', 'June',
'July', 'August', 'September', 'October', 'November', 'December'];


// ─── Calendar helpers ────────────────────────────────────────────────────────

function pad(n: number) {return n < 10 ? '0' + n : '' + n;}
function dateKey(y: number, m: number, d: number) {
  return `${y}-${pad(m + 1)}-${pad(d)}`;
}

function isUnavailable(y: number, m: number, d: number): boolean {
  const key = dateKey(y, m, d);
  const dow = new Date(y, m, d).getDay(); // 0=Sun, 6=Sat
  return dow === 0 || BLOCKED_DATES.includes(key); // Sundays closed
}

function isPast(y: number, m: number, d: number): boolean {
  const today = new Date();
  const t = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  return new Date(y, m, d) < t;
}

// ─── Calendar component ───────────────────────────────────────────────────────

interface CalendarProps {
  selectedDate: string | null;
  onSelectDate: (key: string) => void;
}

function Calendar({ selectedDate, onSelectDate }: CalendarProps) {
  const today = new Date();
  const [current, setCurrent] = useState(
    new Date(today.getFullYear(), today.getMonth(), 1)
  );

  const y = current.getFullYear();
  const m = current.getMonth();

  const firstDow = new Date(y, m, 1).getDay();
  const offset = (firstDow + 6) % 7; // Monday-start
  const daysInMonth = new Date(y, m + 1, 0).getDate();

  const canGoPrev =
  !(y === today.getFullYear() && m <= today.getMonth());

  const days: Array<{d: number | null;key: string | null;unavail: boolean;isToday: boolean;}> = [];

  for (let i = 0; i < offset; i++) {
    days.push({ d: null, key: null, unavail: true, isToday: false });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const key = dateKey(y, m, d);
    const isToday =
    d === today.getDate() && m === today.getMonth() && y === today.getFullYear();
    const unavail = isUnavailable(y, m, d) || isPast(y, m, d);
    days.push({ d, key, unavail, isToday });
  }

  return (
    <div>
      {/* Month nav */}
      <div className="sc-cal-nav" role="group" aria-label="Month navigation">
        <button
          type="button"
          className="sc-cal-nav-btn"
          aria-label="Previous month"
          disabled={!canGoPrev}
          onClick={() => setCurrent(new Date(y, m - 1, 1))}>
          
          <svg width="8" height="14" viewBox="0 0 8 14" fill="none"
          stroke="currentColor" strokeWidth="1.5"
          strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <polyline points="7 1 1 7 7 13" />
          </svg>
        </button>
        <h2 className="sc-cal-heading" aria-live="polite">
          {MONTHS[m]} {y}
        </h2>
        <button
          type="button"
          className="sc-cal-nav-btn"
          aria-label="Next month"
          onClick={() => setCurrent(new Date(y, m + 1, 1))}>
          
          <svg width="8" height="14" viewBox="0 0 8 14" fill="none"
          stroke="currentColor" strokeWidth="1.5"
          strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <polyline points="1 1 7 7 1 13" />
          </svg>
        </button>
      </div>

      {/* Weekday headers */}
      <div className="sc-cal-weekdays" aria-hidden="true">
        {['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'].map((d) =>
        <span key={d} className="sc-cal-weekday">{d}</span>
        )}
      </div>

      {/* Day grid */}
      <div className="sc-cal-grid" role="grid" aria-label={`${MONTHS[m]} ${y}`}>
        {days.map((cell, i) => {
          if (!cell.d || !cell.key) {
            return <div key={`empty-${i}`} className="sc-cal-day sc-cal-day--empty" aria-hidden="true" />;
          }
          const isSelected = cell.key === selectedDate;
          let cls = 'sc-cal-day';
          if (cell.isToday) cls += ' sc-cal-day--today';
          if (cell.unavail) cls += ' sc-cal-day--unavailable';
          if (isSelected) cls += ' sc-cal-day--selected';

          return (
            <button
              key={cell.key}
              type="button"
              className={cls}
              aria-label={`${MONTHS[m]} ${cell.d}, ${y}${cell.unavail ? ', unavailable' : ''}${isSelected ? ', selected' : ''}`}
              aria-disabled={cell.unavail ? 'true' : undefined}
              onClick={() => !cell.unavail && onSelectDate(cell.key!)}>
              
              {cell.d}
            </button>);

        })}
      </div>
    </div>);

}

// ─── Time slots component ─────────────────────────────────────────────────────

interface TimeSlotsProps {
  dateKey: string;
  selectedTime: string | null;
  onSelectTime: (t: string) => void;
}

function TimeSlots({ dateKey: dk, selectedTime, onSelectTime }: TimeSlotsProps) {
  const booked = BOOKED_SLOTS[dk] ?? [];

  return (
    <div className="sc-times">
      <span className="sc-times-label" id="times-label">Available times</span>
      <div className="sc-times-grid" role="group" aria-labelledby="times-label">
        {ALL_SLOTS.map((slot) => {
          const unavail = booked.includes(slot);
          const selected = slot === selectedTime;
          let cls = 'sc-time-btn';
          if (unavail) cls += ' sc-time-btn--unavailable';
          if (selected) cls += ' sc-time-btn--selected';
          return (
            <button
              key={slot}
              type="button"
              className={cls}
              aria-label={slot + (unavail ? ', fully booked' : '')}
              aria-disabled={unavail ? 'true' : undefined}
              onClick={() => !unavail && onSelectTime(slot)}>
              
              {slot}
            </button>);

        })}
      </div>
    </div>);

}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function BookingPage() {
  const site = 'https://sugarcoatednails.net';
  const title = 'Book an Appointment — SugarCoated Nails';
  const description =
  'Book your nail appointment at SugarCoated Nails. Choose your service, pick a date and time, and we\'ll take care of the rest.';
  const canonicalUrl = `${site}/booking`;

  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedRitual, setSelectedRitual] = useState<string>(RITUAL_OPTIONS[0].id);
  const [submitted, setSubmitted] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const firstNameRef = useRef<HTMLInputElement>(null);
  const emailRef = useRef<HTMLInputElement>(null);

  const handleSelectDate = useCallback((key: string) => {
    setSelectedDate(key);
    setSelectedTime(null);
  }, []);

  const handleSelectTime = useCallback((t: string) => {
    setSelectedTime(t);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const firstName = firstNameRef.current?.value.trim();
    const email = emailRef.current?.value.trim();

    if (!firstName) {setFormError('Please enter your first name.');return;}
    if (!email || !email.includes('@')) {setFormError('Please enter a valid email address.');return;}
    if (!selectedDate) {setFormError('Please select a date.');return;}
    if (!selectedTime) {setFormError('Please select a time.');return;}

    setFormError(null);
    setSubmitted(true);
  };

  // Format the selected date for display
  const displayDate = selectedDate ?
  (() => {
    const [y, mo, d] = selectedDate.split('-').map(Number);
    return `${MONTHS[mo - 1]} ${d}, ${y}`;
  })() :
  null;

  const selectedRitualData = RITUAL_OPTIONS.find((r) => r.id === selectedRitual);

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            '@id': `${canonicalUrl}#webpage`,
            name: title,
            url: canonicalUrl,
            isPartOf: { '@id': `${site}/#website` },
            about: { '@id': `${site}/#organization` }
          })}</script>
      </Helmet>

      <main>
        {/* ── Page header ── */}
        <motion.div
          className="sc-booking-header"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut' as const }}>
          
          <div className="sc-booking-header-left">
            <span className="sc-eyebrow">Appointments</span>
            <h1 className="sc-booking-title">Book your appointment</h1>
          </div>
          <div className="sc-booking-header-meta">
            <div className="sc-booking-meta-item">
              <span className="sc-meta-label">Location</span>
              <span className="sc-meta-value">Your city, by request</span>
            </div>
            <span className="sc-meta-sep" aria-hidden="true" />
            <div className="sc-booking-meta-item">
              <span className="sc-meta-label">Hours</span>
              <span className="sc-meta-value">Tue – Sat</span>
            </div>
            <span className="sc-meta-sep" aria-hidden="true" />
            <div className="sc-booking-meta-item">
              <span className="sc-meta-label">Deposit</span>
              <span className="sc-meta-value">$  to hold</span>
            </div>
          </div>
        </motion.div>

        {submitted ? (
        /* ── Confirmation state ── */
        <motion.div
          className="sc-confirmation"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: 'easeOut' as const }}>
          
            <span className="sc-eyebrow">You're booked</span>
            <p className="sc-confirm-headline">
              See you {displayDate} at {selectedTime}
            </p>
            <p className="sc-confirm-body">
              A confirmation email is on its way. If you need to reschedule, reply to that email at least 48 hours before your appointment.
            </p>
            <div className="sc-confirm-detail">
              <span className="sc-meta-label">Service</span>
              <span className="sc-confirm-service">{selectedRitualData?.name}</span>
            </div>
            <Link to="/services" className="sc-btn-ghost-confirm">
              View all services
            </Link>
          </motion.div>) : (

        /* ── Two-column booking interface ── */
        <div className="sc-booking-body">

            {/* ── Left: calendar ── */}
            <section className="sc-calendar-col" aria-label="Select a date">
              <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.1, ease: 'easeOut' as const }}>
              
                <Calendar selectedDate={selectedDate} onSelectDate={handleSelectDate} />

                {selectedDate &&
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, ease: 'easeOut' as const }}>
                
                    <TimeSlots
                  dateKey={selectedDate}
                  selectedTime={selectedTime}
                  onSelectTime={handleSelectTime} />
                
                  </motion.div>
              }
              </motion.div>
            </section>

            {/* ── Right: booking form ── */}
            <section className="sc-booking-col">
              <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.15, ease: 'easeOut' as const }}>
              
                {/* Service selector */}
                <div className="sc-ritual-selector">
                  <span className="sc-field-eyebrow">Choose your service</span>
                  <div className="sc-ritual-options" role="radiogroup" aria-label="Service type">
                    {RITUAL_OPTIONS.map((opt) =>
                  <label key={opt.id} className="sc-ritual-option">
                        <input
                      type="radio"
                      name="ritual"
                      value={opt.id}
                      className="sc-ritual-radio"
                      checked={selectedRitual === opt.id}
                      onChange={() => setSelectedRitual(opt.id)} />
                    
                        <span className="sc-ritual-mark" aria-hidden="true" />
                        <span className="sc-ritual-info">
                          <span className="sc-ritual-name">{opt.name}</span>
                          <span className="sc-ritual-duration">{opt.duration}</span>
                        </span>
                        <span className="sc-ritual-price">{opt.price}</span>
                      </label>
                  )}
                  </div>
                </div>

                {/* Guest details form */}
                <form className="sc-booking-form" noValidate onSubmit={handleSubmit} aria-label="Your details">

                  <div className="sc-form-section">
                    <span className="sc-field-eyebrow">Your details</span>

                    <div className="sc-form-row">
                      <div className="sc-form-field">
                        <label className="sc-form-label" htmlFor="sc-first-name">First name</label>
                        <input
                        ref={firstNameRef}
                        className="sc-form-input"
                        type="text"
                        id="sc-first-name"
                        name="first-name"
                        autoComplete="given-name"
                        required />
                      
                      </div>
                      <div className="sc-form-field">
                        <label className="sc-form-label" htmlFor="sc-last-name">Last name</label>
                        <input
                        className="sc-form-input"
                        type="text"
                        id="sc-last-name"
                        name="last-name"
                        autoComplete="family-name" />
                      
                      </div>
                    </div>

                    <div className="sc-form-field">
                      <label className="sc-form-label" htmlFor="sc-email">Email</label>
                      <input
                      ref={emailRef}
                      className="sc-form-input"
                      type="email"
                      id="sc-email"
                      name="email"
                      placeholder="you@example.com"
                      autoComplete="email"
                      required />
                    
                    </div>

                    <div className="sc-form-field">
                      <label className="sc-form-label" htmlFor="sc-phone">
                        Phone <span className="sc-label-optional">— optional</span>
                      </label>
                      <input
                      className="sc-form-input"
                      type="tel"
                      id="sc-phone"
                      name="phone"
                      autoComplete="tel" />
                    
                    </div>
                  </div>

                  <div className="sc-form-section">
                    <span className="sc-field-eyebrow">Anything we should know</span>
                    <div className="sc-form-field">
                      <label className="sc-form-label" htmlFor="sc-notes">Allergies, sensitivities, inspo</label>
                      <textarea
                      className="sc-form-textarea"
                      id="sc-notes"
                      name="notes"
                      rows={3}
                      placeholder="e.g. gel allergy, bring reference photos, short nails only…" />
                    
                      <span className="sc-form-hint">Read before your appointment — not after.</span>
                    </div>
                  </div>

                  {/* Selected appointment summary */}
                  {(selectedDate || selectedTime) &&
                <motion.div
                  className="sc-appt-summary"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, ease: 'easeOut' as const }}>
                  
                      <span className="sc-field-eyebrow">Your appointment</span>
                      <div className="sc-appt-chips">
                        {selectedDate &&
                    <span className="sc-appt-chip">{displayDate}</span>
                    }
                        {selectedTime &&
                    <span className="sc-appt-chip sc-appt-chip--time">{selectedTime}</span>
                    }
                        {selectedRitualData &&
                    <span className="sc-appt-chip">{selectedRitualData.name}</span>
                    }
                      </div>
                    </motion.div>
                }

                  {formError &&
                <p className="sc-form-error" role="alert">{formError}</p>
                }

                  {/* Submit */}
                  <div className="sc-booking-submit">
                    <button type="submit" className="sc-submit-action">
                      Reserve your spot —
                    </button>
                    <p className="sc-submit-note">A $ deposit holds your time. Confirmation by email within the hour.

                  </p>
                  </div>

                </form>
              </motion.div>
            </section>

          </div>)
        }

        {/* ── Sky closing band ── */}
        <motion.section
          className="sc-booking-cta"
          aria-label="What to expect"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: 'easeOut' as const }}>
          
          <div className="sc-cta-text">
            <span className="sc-eyebrow" style={{ color: 'hsl(var(--muted-foreground))' }}>
              What to expect
            </span>
            <p className="sc-cta-headline">
              your nails, done right
            </p>
            <p className="sc-cta-body">
              Arrive a few minutes early. Bring your inspo or trust the process — either way, you'll leave obsessed. Every appointment includes a complimentary hand or foot massage.
            </p>
          </div>
          <Link to="/portfolio" className="sc-btn-ghost-sky">
            Browse the portfolio
          </Link>
        </motion.section>
      </main>

      {/* ── Scoped styles ── */}
      <style>{`
        /* ── Page header ── */
        .sc-booking-header {
          padding: 56px 64px 48px;
          border-bottom: 1.5px solid hsl(var(--primary));
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 48px;
          flex-wrap: wrap;
        }

        .sc-booking-header-left {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .sc-eyebrow {
          display: block;
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .sc-booking-title {
          font-family: var(--font-heading);
          font-size: clamp(32px, 3.5vw, 48px);
          font-weight: 300;
          letter-spacing: 0.04em;
          line-height: 1.05;
          color: hsl(var(--primary));
          margin: 0;
        }

        .sc-booking-header-meta {
          display: flex;
          align-items: center;
          gap: 24px;
          flex-shrink: 0;
          padding-bottom: 6px;
          flex-wrap: wrap;
        }

        .sc-booking-meta-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
          align-items: flex-end;
        }

        .sc-meta-label {
          font-family: var(--font-heading);
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .sc-meta-value {
          font-family: var(--font-heading);
          font-size: 17px;
          font-weight: 400;
          letter-spacing: 0.03em;
          color: hsl(var(--primary));
          line-height: 1.1;
        }

        .sc-meta-sep {
          width: 1px;
          height: 32px;
          background: hsl(var(--primary) / 0.25);
          flex-shrink: 0;
        }

        /* ── Two-column body ── */
        .sc-booking-body {
          display: grid;
          grid-template-columns: 1fr 1fr;
          align-items: start;
          min-height: 60vh;
        }

        /* ── Calendar column ── */
        .sc-calendar-col {
          padding: 48px 52px 64px;
          border-right: 1px solid hsl(var(--primary) / 0.2);
          position: sticky;
          top: 80px;
        }

        /* Month nav */
        .sc-cal-nav {
          display: grid;
          grid-template-columns: 32px 1fr 32px;
          align-items: center;
          padding-bottom: 14px;
          border-bottom: 1.5px solid hsl(var(--primary));
          margin-bottom: 0;
        }

        .sc-cal-nav-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 32px;
          height: 32px;
          background: none;
          border: none;
          cursor: pointer;
          border-radius: 4px;
          color: hsl(var(--muted-foreground));
          transition: color 180ms ease;
          padding: 0;
        }

        .sc-cal-nav-btn:hover:not(:disabled) { color: hsl(var(--primary)); }
        .sc-cal-nav-btn:disabled { opacity: 0.3; cursor: not-allowed; }
        .sc-cal-nav-btn:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 3px;
        }

        .sc-cal-heading {
          text-align: center;
          font-family: var(--font-heading);
          font-size: 20px;
          font-weight: 400;
          letter-spacing: 0.04em;
          color: hsl(var(--primary));
          line-height: 1;
          margin: 0;
        }

        /* Weekday row */
        .sc-cal-weekdays {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          padding: 18px 0 10px;
          border-bottom: 1px solid hsl(var(--primary) / 0.2);
          margin-bottom: 8px;
        }

        .sc-cal-weekday {
          font-family: var(--font-heading);
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          text-align: center;
          line-height: 1;
        }

        /* Day grid */
        .sc-cal-grid {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 4px 0;
        }

        .sc-cal-day {
          display: flex;
          align-items: center;
          justify-content: center;
          aspect-ratio: 1;
          min-height: 48px;
          background: none;
          border: none;
          cursor: pointer;
          border-radius: 6px;
          font-family: var(--font-sans);
          font-size: 15px;
          font-weight: 400;
          color: hsl(var(--foreground));
          position: relative;
          transition: background 180ms ease, color 180ms ease;
        }

        .sc-cal-day:hover:not(.sc-cal-day--unavailable):not(.sc-cal-day--selected) {
          background: hsl(var(--secondary) / 0.15);
        }

        .sc-cal-day:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: -1px;
        }

        .sc-cal-day--today {
          font-weight: 600;
          color: hsl(var(--primary));
        }

        .sc-cal-day--today::after {
          content: '';
          position: absolute;
          bottom: 7px;
          left: 50%;
          transform: translateX(-50%);
          width: 14px;
          height: 1.5px;
          background: hsl(var(--primary));
          border-radius: 9999px;
        }

        .sc-cal-day--selected {
          background: hsl(var(--primary));
          color: hsl(var(--primary-foreground));
          font-weight: 500;
        }

        .sc-cal-day--selected:hover {
          background: hsl(var(--secondary));
        }

        .sc-cal-day--unavailable {
          color: hsl(var(--muted-foreground));
          opacity: 0.35;
          cursor: not-allowed;
        }

        .sc-cal-day--empty {
          pointer-events: none;
        }

        /* Time slots */
        .sc-times {
          margin-top: 32px;
          padding-top: 28px;
          border-top: 1px solid hsl(var(--primary) / 0.2);
        }

        .sc-times-label {
          display: block;
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
          margin-bottom: 16px;
        }

        .sc-times-grid {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
        }

        .sc-time-btn {
          display: inline-flex;
          align-items: center;
          padding: 9px 18px;
          background: transparent;
          color: hsl(var(--muted-foreground));
          font-family: var(--font-sans);
          font-size: 13px;
          font-weight: 400;
          line-height: 1;
          border: 1px solid hsl(var(--primary) / 0.3);
          border-radius: 9999px;
          cursor: pointer;
          transition: background 180ms ease, border-color 180ms ease, color 180ms ease;
          white-space: nowrap;
        }

        .sc-time-btn:hover:not(.sc-time-btn--unavailable) {
          border-color: hsl(var(--primary));
          color: hsl(var(--primary));
        }

        .sc-time-btn--selected {
          background: hsl(var(--secondary) / 0.2);
          border-color: hsl(var(--primary));
          color: hsl(var(--primary));
          font-weight: 500;
        }

        .sc-time-btn--unavailable {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .sc-time-btn:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 3px;
        }

        /* ── Booking column ── */
        .sc-booking-col {
          padding: 48px 52px 72px;
        }

        /* Service selector */
        .sc-ritual-selector {
          padding-bottom: 32px;
          margin-bottom: 32px;
          border-bottom: 1px solid hsl(var(--primary) / 0.2);
        }

        .sc-field-eyebrow {
          display: block;
          font-family: var(--font-heading);
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
          margin-bottom: 14px;
        }

        .sc-ritual-options {
          display: flex;
          flex-direction: column;
          border-top: 1px solid hsl(var(--primary) / 0.15);
        }

        .sc-ritual-option {
          display: grid;
          grid-template-columns: 20px 1fr auto;
          align-items: center;
          gap: 14px;
          padding: 16px 4px;
          border-bottom: 1px solid hsl(var(--primary) / 0.15);
          cursor: pointer;
        }

        .sc-ritual-option:hover .sc-ritual-name {
          color: hsl(var(--secondary));
        }

        .sc-ritual-radio {
          position: absolute;
          width: 1px;
          height: 1px;
          opacity: 0;
          pointer-events: none;
        }

        .sc-ritual-mark {
          width: 16px;
          height: 16px;
          border: 1.5px solid hsl(var(--primary));
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          transition: border-color 180ms ease;
        }

        .sc-ritual-radio:checked + .sc-ritual-mark::after {
          content: '';
          display: block;
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: hsl(var(--primary));
        }

        .sc-ritual-radio:focus-visible + .sc-ritual-mark {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 3px;
        }

        .sc-ritual-info {
          display: flex;
          flex-direction: column;
          gap: 3px;
        }

        .sc-ritual-name {
          font-family: var(--font-heading);
          font-size: 16px;
          font-weight: 400;
          letter-spacing: 0.03em;
          color: hsl(var(--primary));
          line-height: 1.1;
          transition: color 180ms ease;
        }

        .sc-ritual-duration {
          font-family: var(--font-sans);
          font-size: 12px;
          font-weight: 400;
          color: hsl(var(--muted-foreground));
          letter-spacing: 0.01em;
        }

        .sc-ritual-price {
          font-family: var(--font-heading);
          font-size: 16px;
          font-weight: 400;
          letter-spacing: 0.03em;
          color: hsl(var(--primary));
          white-space: nowrap;
        }

        /* Form */
        .sc-booking-form {
          display: flex;
          flex-direction: column;
          gap: 0;
        }

        .sc-form-section {
          display: flex;
          flex-direction: column;
          gap: 24px;
          padding-bottom: 32px;
          margin-bottom: 32px;
          border-bottom: 1px solid hsl(var(--primary) / 0.2);
        }

        .sc-form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 24px;
        }

        .sc-form-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .sc-form-label {
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .sc-label-optional {
          font-weight: 400;
          letter-spacing: 0;
          text-transform: none;
          font-size: 11px;
          color: hsl(var(--muted-foreground));
        }

        .sc-form-input {
          font-family: var(--font-sans);
          font-size: 16px;
          font-weight: 400;
          color: hsl(var(--foreground));
          background: transparent;
          border: none;
          border-bottom: 1px solid hsl(var(--primary) / 0.3);
          border-radius: 0;
          padding: 8px 0 10px;
          outline: none;
          line-height: 1.5;
          width: 100%;
          transition: border-color 180ms ease;
        }

        .sc-form-input::placeholder { color: hsl(var(--muted-foreground)); }
        .sc-form-input:hover { border-bottom-color: hsl(var(--primary) / 0.6); }
        .sc-form-input:focus { border-bottom-color: hsl(var(--primary)); }

        .sc-form-textarea {
          font-family: var(--font-sans);
          font-size: 16px;
          font-weight: 400;
          color: hsl(var(--foreground));
          background: transparent;
          border: none;
          border-bottom: 1px solid hsl(var(--primary) / 0.3);
          border-radius: 0;
          padding: 8px 0 10px;
          outline: none;
          line-height: 1.65;
          resize: vertical;
          min-height: 80px;
          width: 100%;
          transition: border-color 180ms ease;
        }

        .sc-form-textarea::placeholder { color: hsl(var(--muted-foreground)); }
        .sc-form-textarea:hover { border-bottom-color: hsl(var(--primary) / 0.6); }
        .sc-form-textarea:focus { border-bottom-color: hsl(var(--primary)); }

        .sc-form-hint {
          font-family: var(--font-sans);
          font-size: 12px;
          color: hsl(var(--muted-foreground));
          line-height: 1.5;
        }

        /* Appointment summary chips */
        .sc-appt-summary {
          padding: 20px 0 28px;
          border-bottom: 1px solid hsl(var(--primary) / 0.2);
          margin-bottom: 0;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .sc-appt-chips {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .sc-appt-chip {
          display: inline-flex;
          align-items: center;
          padding: 6px 14px;
          background: hsl(var(--secondary) / 0.15);
          border: 1px solid hsl(var(--primary) / 0.3);
          border-radius: 9999px;
          font-family: var(--font-sans);
          font-size: 13px;
          font-weight: 400;
          color: hsl(var(--primary));
          line-height: 1;
        }

        .sc-appt-chip--time {
          background: hsl(var(--primary) / 0.1);
          border-color: hsl(var(--primary));
          font-weight: 500;
        }

        /* Error */
        .sc-form-error {
          font-family: var(--font-sans);
          font-size: 14px;
          color: hsl(var(--destructive));
          line-height: 1.5;
          padding: 12px 0 0;
        }

        /* Submit */
        .sc-booking-submit {
          margin-top: 40px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          align-items: flex-start;
        }

        .sc-submit-action {
          background: none;
          border: none;
          padding: 8px 0;
          cursor: pointer;
          font-family: var(--font-heading);
          font-style: italic;
          font-weight: 300;
          font-size: clamp(24px, 2.8vw, 34px);
          letter-spacing: 0.03em;
          line-height: 1.1;
          color: hsl(var(--primary));
          border-bottom: 1.5px solid hsl(var(--primary));
          transition: color 180ms ease, border-color 180ms ease;
        }

        .sc-submit-action:hover {
          color: hsl(var(--secondary));
          border-bottom-color: hsl(var(--secondary));
        }

        .sc-submit-action:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 6px;
          border-radius: 4px;
        }

        .sc-submit-note {
          font-family: var(--font-sans);
          font-size: 12px;
          color: hsl(var(--muted-foreground));
          line-height: 1.6;
          max-width: 44ch;
        }

        /* ── Confirmation ── */
        .sc-confirmation {
          max-width: 640px;
          margin: 0 auto;
          padding: 80px 64px 96px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .sc-confirm-headline {
          font-family: var(--font-heading);
          font-size: clamp(28px, 3vw, 42px);
          font-weight: 300;
          font-style: italic;
          letter-spacing: 0.03em;
          line-height: 1.1;
          color: hsl(var(--primary));
          margin: 0;
        }

        .sc-confirm-body {
          font-family: var(--font-sans);
          font-size: 16px;
          font-weight: 400;
          line-height: 1.65;
          color: hsl(var(--muted-foreground));
          max-width: 52ch;
          margin: 0;
        }

        .sc-confirm-detail {
          display: flex;
          flex-direction: column;
          gap: 4px;
          padding-top: 8px;
        }

        .sc-confirm-service {
          font-family: var(--font-heading);
          font-size: 20px;
          font-weight: 400;
          letter-spacing: 0.03em;
          color: hsl(var(--primary));
        }

        .sc-btn-ghost-confirm {
          display: inline-flex;
          align-items: center;
          margin-top: 8px;
          padding: 12px 28px;
          background: transparent;
          color: hsl(var(--primary));
          font-family: var(--font-heading);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-decoration: none;
          border: 1.5px solid hsl(var(--primary));
          border-radius: 9999px;
          transition: background 200ms ease, color 200ms ease;
        }

        .sc-btn-ghost-confirm:hover {
          background: hsl(var(--primary));
          color: hsl(var(--primary-foreground));
        }

        /* ── Sky closing band ── */
        .sc-booking-cta {
          background: hsl(var(--accent));
          border-top: 1.5px solid hsl(var(--primary));
          padding: 72px 64px 88px;
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 48px;
        }

        .sc-cta-text {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .sc-cta-headline {
          font-family: var(--font-heading);
          font-size: clamp(28px, 3vw, 44px);
          font-weight: 300;
          font-style: italic;
          letter-spacing: 0.03em;
          line-height: 1.1;
          color: hsl(var(--primary));
          max-width: 22ch;
          margin: 0;
        }

        .sc-cta-body {
          font-family: var(--font-sans);
          font-size: 15px;
          font-weight: 400;
          line-height: 1.65;
          color: hsl(var(--muted-foreground));
          max-width: 48ch;
          margin: 0;
        }

        .sc-btn-ghost-sky {
          display: inline-flex;
          align-items: center;
          flex-shrink: 0;
          align-self: flex-end;
          padding: 12px 28px;
          background: transparent;
          color: hsl(var(--primary));
          font-family: var(--font-heading);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-decoration: none;
          border: 1.5px solid hsl(var(--primary));
          border-radius: 9999px;
          transition: background 200ms ease, color 200ms ease;
          white-space: nowrap;
        }

        .sc-btn-ghost-sky:hover {
          background: hsl(var(--primary));
          color: hsl(var(--primary-foreground));
        }

        .sc-btn-ghost-sky:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 3px;
        }

        /* ── Responsive ── */
        @media (max-width: 900px) {
          .sc-booking-header {
            padding: 40px 32px 36px;
            flex-direction: column;
            align-items: flex-start;
            gap: 24px;
          }

          .sc-booking-header-meta {
            padding-bottom: 0;
          }

          .sc-booking-meta-item {
            align-items: flex-start;
          }

          .sc-booking-body {
            grid-template-columns: 1fr;
          }

          .sc-calendar-col {
            position: relative;
            top: auto;
            border-right: none;
            border-bottom: 1px solid hsl(var(--primary) / 0.2);
            padding: 40px 32px 48px;
          }

          .sc-booking-col {
            padding: 40px 32px 64px;
          }

          .sc-booking-cta {
            flex-direction: column;
            align-items: flex-start;
            gap: 28px;
            padding: 56px 32px 72px;
          }
        }

        @media (max-width: 560px) {
          .sc-booking-header {
            padding: 32px 20px 28px;
          }

          .sc-meta-sep { display: none; }

          .sc-booking-header-meta {
            flex-direction: row;
            flex-wrap: wrap;
            gap: 16px;
          }

          .sc-calendar-col {
            padding: 32px 20px 40px;
          }

          .sc-cal-day {
            font-size: 14px;
            min-height: 40px;
          }

          .sc-cal-weekday { font-size: 9px; }
          .sc-cal-heading { font-size: 18px; }

          .sc-booking-col {
            padding: 32px 20px 56px;
          }

          .sc-form-row {
            grid-template-columns: 1fr;
            gap: 20px;
          }

          .sc-booking-cta {
            padding: 48px 20px 64px;
          }

          .sc-confirmation {
            padding: 56px 20px 72px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .sc-cal-day,
          .sc-time-btn,
          .sc-form-input,
          .sc-form-textarea,
          .sc-submit-action,
          .sc-btn-ghost-sky,
          .sc-btn-ghost-confirm { transition: none; }
        }
      `}</style>
    </>);

}