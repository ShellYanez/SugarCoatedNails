import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

const ease = [0.25, 0.46, 0.45, 0.94] as const;

export default function AboutPage() {
  const site = 'https://sugarcoatednails.net';
  const title = 'About — SugarCoated Nails';
  const description =
  'Meet the person behind SugarCoated Nails — a nail boutique built on precision, warmth, and the belief that your nails deserve to be obsessed over.';
  const canonicalUrl = `${site}/about`;

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'AboutPage',
            '@id': `${canonicalUrl}#webpage`,
            name: title,
            url: canonicalUrl,
            isPartOf: { '@id': `${site}/#website` },
            about: { '@id': `${site}/#organization` }
          })}</script>
      </Helmet>

      <main>
        {/* ── Two-column body ── */}
        <div className="ab-body">

          {/* ── Left: sticky portrait ── */}
          <figure
            className="ab-portrait"
            role="img"
            aria-label="The founder of SugarCoated Nails — photographed at the studio">
            
            







            
            <figcaption className="ab-portrait__credit" aria-hidden="true">
              SugarCoated Nails Studio
            </figcaption>
          </figure>

          {/* ── Right: story column ── */}
          <article className="ab-story" aria-label="About SugarCoated Nails">

            {/* Identity zone */}
            <header className="ab-identity">
              <motion.span
                className="ab-eyebrow"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1, ease }}>
                
                SugarCoated Nails — Nail Boutique
              </motion.span>
              <motion.p
                className="ab-brand-tagline"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2, ease }}>
                
                A nail boutique built on the belief that your nails are the
                finishing touch — and the finishing touch deserves to be
                done right.
              </motion.p>
            </header>

            {/* Essay */}
            <div className="ab-essay">

              <motion.p
                className="ab-paragraph"
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>It started the way most things do....with a problem I couldn't stop thinking about. I'd been getting my nails done for years, and every time I left a salon I felt like something was slightly off. Not wrong, exactly. Just not quite right. The shape wasn't mine. The color was close but not it. The art was pretty but generic. I wanted nails that felt like me, and I couldn't find anyone who'd take that seriously.








              </motion.p>

              <motion.p
                className="ab-paragraph"
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>So I learned to do it myself. That was the beginning. What started as obsessive practice on my own hands turned into something I couldn't stop sharing, first with friends, then with their friends, then with strangers who found me online and sent me photos of nails they'd been dreaming about.






              </motion.p>

              {/* The h1 — arrives mid-essay as the thesis */}
              <motion.h1
                className="ab-thesis"
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease }}>
                
                your nails,
                <br />
                done right
              </motion.h1>

              <motion.p
                className="ab-paragraph"
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>That phrase became the whole thing. Not "done fast." Not "done cheap." Done right, which means done for you, specifically. Your nail shape, your lifestyle, your reference photos, your vibe. Every appointment starts with a conversation because the best nail art isn't just technically good. It fits.






              </motion.p>

              {/* Section marker */}
              <motion.div
                className="ab-section-marker"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>
                
                <span className="ab-section-label">The approach</span>
                <span className="ab-section-rule" aria-hidden="true" />
              </motion.div>

              <motion.p
                className="ab-paragraph"
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>
                
                I work with a small number of clients at a time — intentionally.
                Rushing through appointments is how you get nails that look fine
                in the salon and chip by Thursday. I'd rather do fewer sets and
                do them properly. That means prep that actually protects your
                natural nail, gel that's applied in thin layers, and art that's
                sealed so it lasts.
              </motion.p>

              {/* Detail rows */}
              <motion.dl
                className="ab-details"
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>
                
                {[
                { label: 'Speciality', value: 'Gel & custom nail art' },
                { label: 'Appointments', value: 'By booking only' },
                { label: 'Deposit', value: 'Required to hold your spot' },
                { label: 'Cancellation', value: '48 hours notice' },
                { label: 'Hours', value: 'Tue – Sat' }].
                map(({ label, value }) =>
                <div className="ab-detail-row" key={label}>
                    <dt className="ab-detail-label">{label}</dt>
                    <dd className="ab-detail-value">{value}</dd>
                  </div>
                )}
              </motion.dl>

              {/* Section marker */}
              <motion.div
                className="ab-section-marker"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>
                
                <span className="ab-section-label">What to expect</span>
                <span className="ab-section-rule" aria-hidden="true" />
              </motion.div>

              <motion.p
                className="ab-paragraph"
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease }}>Bring your inspo or come with nothing... either works. If you have a vision, I wil make it happen. If you're not sure what you want, we'll figure it out together. The only thing I ask is that you arrive a few minutes early and tell me honestly what you like and don't like. Good nails require good communication.







              </motion.p>

              {/* Pullquote */}
              <motion.figure
                className="ab-pullquote"
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, ease }}>
                
                <blockquote className="ab-pullquote__text">
                  "I've never left an appointment not completely obsessed.
                  She just gets it."
                </blockquote>
                <figcaption className="ab-pullquote__attr">
                </figcaption>
              </motion.figure>

              {/* Studio image — breaks the text rhythm */}
              <motion.div
                className="ab-studio-img-wrap"
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease }}>
                
                





                
                
              </motion.div>

              <div className="ab-closing">
                <motion.p
                  className="ab-paragraph"
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, ease }}>
                  
                  Every appointment includes a complimentary hand or foot
                  massage — because you came here to be taken care of, and
                  that starts the moment you sit down. I'm glad you're here.
                  Let's make something you'll love.
                </motion.p>
              </div>

            </div>
          </article>
        </div>

        {/* ── Sky closing band ── */}
        <motion.section
          className="ab-sky"
          aria-label="Book an appointment"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, ease }}>
          
          <div className="ab-sky__text">
            <span className="ab-sky__eyebrow">Ready when you are</span>
            <h2 className="ab-sky__headline">
              let's make your
              <br />
              nails happen
            </h2>
            <p className="ab-sky__body">
              Browse the portfolio for inspo, check the services menu for
              pricing, or go straight to booking. Your spot is waiting.
            </p>
          </div>
          <div className="ab-sky__actions">
            <Link to="/booking" className="ab-sky__btn-primary">
              Book an appointment
            </Link>
            <Link to="/portfolio" className="ab-sky__btn-ghost">
              Browse the portfolio
            </Link>
          </div>
        </motion.section>
      </main>

      {/* ── Scoped styles ── */}
      <style>{`
        /* ── Two-column body ── */
        .ab-body {
          display: grid;
          grid-template-columns: 52fr 48fr;
          align-items: start;
          position: relative;
        }

        /* ── Portrait column ── */
        .ab-portrait {
          position: sticky;
          top: 72px; /* clears the site header */
          height: calc(100svh - 72px);
          overflow: hidden;
          background: hsl(var(--muted));
          margin: 0;
        }

        .ab-portrait__img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center 15%;
          display: block;
        }

        .ab-portrait__credit {
          position: absolute;
          bottom: 24px;
          left: 28px;
          font-family: var(--font-sans);
          font-size: 10px;
          font-weight: 400;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: hsl(var(--primary-foreground));
          opacity: 0.45;
          pointer-events: none;
          line-height: 1;
        }

        /* ── Story column ── */
        .ab-story {
          background: hsl(var(--background));
          padding: 88px 64px 0 64px;
          border-left: 1px solid hsl(var(--primary) / 0.2);
          min-height: calc(100svh - 72px);
        }

        /* Identity zone */
        .ab-identity {
          margin-bottom: 56px;
          padding-bottom: 48px;
          border-bottom: 1.5px solid hsl(var(--primary));
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .ab-eyebrow {
          display: block;
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .ab-brand-tagline {
          font-family: var(--font-sans);
          font-size: 17px;
          font-weight: 400;
          line-height: 1.65;
          color: hsl(var(--muted-foreground));
          max-width: 46ch;
          margin: 0;
        }

        /* Essay */
        .ab-essay {
          display: flex;
          flex-direction: column;
        }

        .ab-paragraph {
          font-family: var(--font-sans);
          font-size: 17px;
          font-weight: 400;
          line-height: 1.7;
          color: hsl(var(--muted-foreground));
          max-width: 54ch;
          margin: 0 0 28px 0;
        }

        /* The h1 — mid-essay thesis */
        .ab-thesis {
          font-family: var(--font-heading);
          font-style: italic;
          font-weight: 300;
          font-size: clamp(34px, 3.8vw, 52px);
          letter-spacing: 0.03em;
          line-height: 1.05;
          color: hsl(var(--primary));
          max-width: 20ch;
          margin: 48px 0 40px;
          padding-top: 40px;
          border-top: 1px solid hsl(var(--primary) / 0.25);
        }

        /* Section markers */
        .ab-section-marker {
          display: flex;
          align-items: center;
          gap: 20px;
          margin: 64px 0 28px;
        }

        .ab-section-label {
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          flex-shrink: 0;
          line-height: 1;
        }

        .ab-section-rule {
          flex: 1;
          height: 1px;
          background: hsl(var(--primary));
        }

        /* Detail rows */
        .ab-details {
          margin: 40px 0 48px;
          border-top: 1px solid hsl(var(--primary) / 0.2);
        }

        .ab-detail-row {
          display: grid;
          grid-template-columns: 1fr auto;
          align-items: baseline;
          gap: 24px;
          padding: 13px 0;
          border-bottom: 1px solid hsl(var(--primary) / 0.2);
        }

        .ab-detail-label {
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .ab-detail-value {
          font-family: var(--font-heading);
          font-size: 16px;
          font-weight: 400;
          letter-spacing: 0.03em;
          color: hsl(var(--primary));
          text-align: right;
          white-space: nowrap;
          margin: 0;
        }

        /* Pullquote */
        .ab-pullquote {
          margin: 56px 0;
          padding: 36px 0;
          border-top: 1px solid hsl(var(--primary));
          border-bottom: 1px solid hsl(var(--primary));
        }

        .ab-pullquote__text {
          font-family: var(--font-heading);
          font-style: italic;
          font-weight: 300;
          font-size: clamp(20px, 2.2vw, 28px);
          letter-spacing: 0.02em;
          line-height: 1.3;
          color: hsl(var(--primary));
          max-width: 38ch;
          margin: 0 0 16px 0;
        }

        .ab-pullquote__attr {
          font-family: var(--font-sans);
          font-size: 12px;
          font-weight: 400;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
        }

        /* Studio image */
        .ab-studio-img-wrap {
          margin: 0 0 40px 0;
          border-radius: 12px;
          overflow: hidden;
        }

        .ab-studio-img {
          width: 100%;
          height: auto;
          display: block;
          object-fit: cover;
        }

        /* Closing */
        .ab-closing {
          padding-bottom: 88px;
        }

        /* ── Sky section ── */
        .ab-sky {
          background: hsl(var(--accent));
          border-top: 1.5px solid hsl(var(--primary));
          padding: 88px 64px 104px;
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 56px;
        }

        .ab-sky__text {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }

        .ab-sky__eyebrow {
          display: block;
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .ab-sky__headline {
          font-family: var(--font-heading);
          font-style: italic;
          font-weight: 300;
          font-size: clamp(30px, 3.5vw, 50px);
          letter-spacing: 0.03em;
          line-height: 1.05;
          color: hsl(var(--primary));
          max-width: 18ch;
          margin: 0;
        }

        .ab-sky__body {
          font-family: var(--font-sans);
          font-size: 16px;
          font-weight: 400;
          line-height: 1.65;
          color: hsl(var(--muted-foreground));
          max-width: 48ch;
          margin: 0;
        }

        .ab-sky__actions {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 12px;
          flex-shrink: 0;
          align-self: flex-end;
        }

        .ab-sky__btn-primary {
          display: inline-flex;
          align-items: center;
          padding: 13px 28px;
          background: hsl(var(--primary));
          color: hsl(var(--primary-foreground));
          font-family: var(--font-heading);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-decoration: none;
          border-radius: 9999px;
          white-space: nowrap;
          transition: transform 200ms cubic-bezier(0.25,0.46,0.45,0.94),
                      box-shadow 200ms cubic-bezier(0.25,0.46,0.45,0.94);
          box-shadow: 0 4px 20px rgba(155,111,190,0.22);
        }

        .ab-sky__btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 28px rgba(155,111,190,0.36);
        }

        .ab-sky__btn-primary:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 3px;
        }

        .ab-sky__btn-ghost {
          display: inline-flex;
          align-items: center;
          padding: 12px 28px;
          background: transparent;
          color: hsl(var(--primary));
          font-family: var(--font-heading);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-decoration: none;
          border: 1.5px solid hsl(var(--primary));
          border-radius: 9999px;
          white-space: nowrap;
          transition: background 200ms cubic-bezier(0.25,0.46,0.45,0.94),
                      color 200ms cubic-bezier(0.25,0.46,0.45,0.94);
        }

        .ab-sky__btn-ghost:hover {
          background: hsl(var(--primary));
          color: hsl(var(--primary-foreground));
        }

        .ab-sky__btn-ghost:focus-visible {
          outline: 2px solid hsl(var(--primary));
          outline-offset: 3px;
        }

        /* ── Responsive ── */
        @media (max-width: 1100px) {
          .ab-body {
            grid-template-columns: 50fr 50fr;
          }
          .ab-story {
            padding: 72px 48px 0 48px;
          }
          .ab-sky {
            padding: 72px 48px 88px;
          }
        }

        @media (max-width: 860px) {
          .ab-body {
            grid-template-columns: 1fr;
          }
          .ab-portrait {
            position: relative;
            top: auto;
            height: 72vw;
            max-height: 520px;
            min-height: 300px;
          }
          .ab-story {
            border-left: none;
            border-top: 1px solid hsl(var(--primary) / 0.2);
            padding: 56px 40px 0 40px;
            min-height: auto;
          }
          .ab-sky {
            flex-direction: column;
            align-items: flex-start;
            gap: 32px;
            padding: 64px 40px 80px;
          }
          .ab-sky__actions {
            align-items: flex-start;
          }
        }

        @media (max-width: 560px) {
          .ab-portrait {
            height: 80vw;
            max-height: none;
          }
          .ab-story {
            padding: 48px 24px 0 24px;
          }
          .ab-identity {
            margin-bottom: 40px;
            padding-bottom: 36px;
          }
          .ab-thesis {
            margin: 36px 0 32px;
            padding-top: 32px;
          }
          .ab-section-marker {
            margin: 48px 0 24px;
          }
          .ab-pullquote {
            margin: 40px 0;
          }
          .ab-closing {
            padding-bottom: 64px;
          }
          .ab-sky {
            padding: 56px 24px 72px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .ab-portrait__img,
          .ab-sky__btn-primary,
          .ab-sky__btn-ghost {
            transition: none;
          }
        }
      `}</style>
    </>);

}