import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

const ease = 'easeOut' as const;

// Gallery categories with staggered tall/short layout
const categories = [
  {
    id: 'gel-ombre',
    slot: '/airo-assets/images/portfolio/gel-ombre-featured',
    label: 'Signature Style',
    name: 'Gel Ombré',
    desc: 'Seamless colour blends from soft blush to deep berry — the gradient that never goes out of style.',
    count: null,
    tall: true,
    pair: 'p1',
    side: 'left',
  },
  {
    id: 'floral',
    slot: '/airo-assets/images/portfolio/nail-art-floral',
    label: 'Hand-Painted',
    name: 'Floral Art',
    desc: null,
    count: null,
    tall: false,
    pair: 'p1',
    side: 'right-a',
  },
  {
    id: 'chrome',
    slot: '/airo-assets/images/portfolio/chrome-abstract',
    label: 'Statement',
    name: 'Chrome & Abstract',
    desc: null,
    count: null,
    tall: false,
    pair: 'p1',
    side: 'right-b',
  },
  {
    id: 'minimalist',
    slot: '/airo-assets/images/portfolio/minimalist-nude',
    label: 'Clean & Classic',
    name: 'Minimalist Nude',
    desc: null,
    count: null,
    tall: false,
    pair: 'p2',
    side: 'left-a',
  },
  {
    id: 'glitter',
    slot: '/airo-assets/images/portfolio/glitter-gems',
    label: 'Glam',
    name: 'Glitter & Gems',
    desc: null,
    count: null,
    tall: false,
    pair: 'p2',
    side: 'left-b',
  },
  {
    id: 'french',
    slot: '/airo-assets/images/portfolio/french-tips-featured',
    label: 'Timeless',
    name: 'French Tips',
    desc: 'The classic reimagined — clean whites, coloured tips, and the kind of finish that photographs beautifully.',
    count: null,
    tall: true,
    pair: 'p2',
    side: 'right',
  },
];

export default function PortfolioPage() {
  const site = 'https://sugarcoatednails.net';
  const title = 'Portfolio — SugarCoated Nails';
  const description = 'Browse our nail art gallery — gel ombré, florals, chrome, French tips, and more. Custom nail art in a warm boutique setting.';
  const canonicalUrl = `${site}/portfolio`;

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* ── Page header ── */}
        <section
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '72px 40px 56px',
          }}
        >
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease }}
          >
            {/* Eyebrow + rule */}
            <div
              style={{
                display: 'flex',
                alignItems: 'baseline',
                justifyContent: 'space-between',
                gap: '24px',
                paddingBottom: '14px',
                borderBottom: '1px solid hsl(var(--primary))',
                marginBottom: '28px',
              }}
            >
              <span
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '11px',
                  fontWeight: 500,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: 'hsl(var(--muted-foreground))',
                }}
              >
                The Work
              </span>
              <span
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '11px',
                  fontWeight: 500,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: 'hsl(var(--muted-foreground))',
                  flexShrink: 0,
                }}
              >
                6 styles
              </span>
            </div>

            <h1
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(36px, 5vw, 60px)',
                fontWeight: 300,
                letterSpacing: '0.04em',
                color: 'hsl(var(--primary))',
                lineHeight: 1.1,
                marginBottom: '20px',
              }}
            >
              The Portfolio
            </h1>
            <p
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: '17px',
                fontWeight: 400,
                color: 'hsl(var(--muted-foreground))',
                lineHeight: 1.65,
                maxWidth: '56ch',
              }}
            >
              Every set is custom — designed around your vibe, your occasion, and your nails. Here's a look at what we love to create.
            </p>
          </motion.div>
        </section>

        {/* ── Staggered gallery grid ── */}
        <section
          aria-label="Nail art gallery"
          style={{
            maxWidth: '1200px',
            margin: '0 auto',
            padding: '0 40px 40px',
          }}
        >
          {/* Pair 1: tall left, two short right */}
          <div className="gallery-grid-pair" style={{ marginBottom: '24px' }}>
            {/* Tall left — Gel Ombré */}
            <motion.div
              className="gallery-card gallery-card--tall gallery-card--p1-left"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0, ease }}
            >
              <GalleryCard item={categories[0]} />
            </motion.div>

            {/* Short right top — Floral */}
            <motion.div
              className="gallery-card gallery-card--short gallery-card--p1-right-a"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.08, ease }}
            >
              <GalleryCard item={categories[1]} />
            </motion.div>

            {/* Short right bottom — Chrome */}
            <motion.div
              className="gallery-card gallery-card--short gallery-card--p1-right-b"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.16, ease }}
            >
              <GalleryCard item={categories[2]} />
            </motion.div>
          </div>

          {/* Sky interlude band */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease }}
            style={{
              background: 'hsl(var(--accent))',
              borderTop: '1px solid hsl(var(--primary))',
              borderBottom: '1px solid hsl(var(--primary))',
              padding: '56px 40px',
              margin: '0 -40px 24px',
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'space-between',
              gap: '40px',
              flexWrap: 'wrap',
            }}
          >
            <div>
              <p
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '11px',
                  fontWeight: 500,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: 'hsl(var(--primary))',
                  marginBottom: '16px',
                }}
              >
                Every set is one of a kind
              </p>
              <p
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(26px, 3.5vw, 44px)',
                  fontWeight: 300,
                  fontStyle: 'italic',
                  letterSpacing: '0.03em',
                  lineHeight: 1.1,
                  color: 'hsl(var(--primary))',
                  maxWidth: '22ch',
                }}
              >
                your nails, your way
              </p>
            </div>
            <Link
              to="/booking"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                padding: '12px 28px',
                background: 'transparent',
                color: 'hsl(var(--primary))',
                fontFamily: 'var(--font-heading)',
                fontSize: '12px',
                fontWeight: 600,
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                textDecoration: 'none',
                borderRadius: '9999px',
                border: '1.5px solid hsl(var(--primary))',
                transition: 'background 200ms ease, color 200ms ease',
                flexShrink: 0,
                alignSelf: 'flex-end',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.background = 'hsl(var(--primary))';
                (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--primary-foreground))';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.background = 'transparent';
                (e.currentTarget as HTMLAnchorElement).style.color = 'hsl(var(--primary))';
              }}
            >
              Book your appointment
            </Link>
          </motion.div>

          {/* Pair 2: two short left, tall right */}
          <div className="gallery-grid-pair">
            {/* Short left top — Minimalist */}
            <motion.div
              className="gallery-card gallery-card--short gallery-card--p2-left-a"
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.08, ease }}
            >
              <GalleryCard item={categories[3]} />
            </motion.div>

            {/* Short left bottom — Glitter */}
            <motion.div
              className="gallery-card gallery-card--short gallery-card--p2-left-b"
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.16, ease }}
            >
              <GalleryCard item={categories[4]} />
            </motion.div>

            {/* Tall right — French Tips */}
            <motion.div
              className="gallery-card gallery-card--tall gallery-card--p2-right"
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0, ease }}
            >
              <GalleryCard item={categories[5]} />
            </motion.div>
          </div>
        </section>

        {/* ── Closing CTA band ── */}
        <motion.section
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease }}
          style={{
            background: 'hsl(var(--secondary))',
            borderTop: '1px solid hsl(var(--primary))',
            padding: '72px 40px 88px',
            marginTop: '72px',
          }}
        >
          <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
            <p
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: '11px',
                fontWeight: 500,
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: 'hsl(var(--muted-foreground))',
                marginBottom: '20px',
              }}
            >
              Ready for your set?
            </p>
            <h2
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(28px, 3.5vw, 48px)',
                fontWeight: 300,
                letterSpacing: '0.04em',
                lineHeight: 1.1,
                color: 'hsl(var(--primary))',
                marginBottom: '16px',
                maxWidth: '20ch',
              }}
            >
              Let's create something beautiful
            </h2>
            <p
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: '16px',
                color: 'hsl(var(--muted-foreground))',
                lineHeight: 1.65,
                maxWidth: '50ch',
                marginBottom: '32px',
              }}
            >
              Bring your inspo, your ideas, or just your vibe — we'll design the perfect set together.
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
              <Link
                to="/booking"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  padding: '14px 36px',
                  background: 'hsl(var(--primary))',
                  color: 'hsl(var(--primary-foreground))',
                  fontFamily: 'var(--font-heading)',
                  fontSize: '13px',
                  fontWeight: 600,
                  letterSpacing: '0.08em',
                  textTransform: 'uppercase',
                  textDecoration: 'none',
                  borderRadius: '9999px',
                  boxShadow: '0 4px 20px rgba(155,111,190,0.25)',
                  transition: 'transform 200ms ease, box-shadow 200ms ease',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-2px)';
                  (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 8px 28px rgba(155,111,190,0.38)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 4px 20px rgba(155,111,190,0.25)';
                }}
              >
                Book now
              </Link>
              <Link
                to="/services"
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '13px',
                  fontWeight: 500,
                  letterSpacing: '0.06em',
                  textTransform: 'uppercase',
                  color: 'hsl(var(--primary))',
                  textDecoration: 'none',
                  paddingBottom: '2px',
                  borderBottom: '1.5px solid hsl(var(--primary))',
                }}
              >
                View services
              </Link>
            </div>
          </div>
        </motion.section>
      </main>

      {/* Inline styles for the staggered grid */}
      <style>{`
        .gallery-grid-pair {
          display: grid;
          grid-template-columns: 1fr 1fr;
          grid-template-rows: 300px 300px;
          gap: 20px;
        }

        /* Pair 1 */
        .gallery-card--p1-left  { grid-column: 1; grid-row: 1 / 3; }
        .gallery-card--p1-right-a { grid-column: 2; grid-row: 1; }
        .gallery-card--p1-right-b { grid-column: 2; grid-row: 2; }

        /* Pair 2 */
        .gallery-card--p2-left-a { grid-column: 1; grid-row: 1; }
        .gallery-card--p2-left-b { grid-column: 1; grid-row: 2; }
        .gallery-card--p2-right  { grid-column: 2; grid-row: 1 / 3; }

        .gallery-card {
          overflow: hidden;
          border-radius: 16px;
          border: 1px solid hsl(var(--border));
          background: hsl(var(--secondary));
          display: flex;
          flex-direction: column;
          cursor: default;
          transition: transform 350ms cubic-bezier(0.25,0.46,0.45,0.94),
                      box-shadow 350ms cubic-bezier(0.25,0.46,0.45,0.94);
        }

        .gallery-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 8px 28px rgba(155,111,190,0.22);
        }

        .gallery-card__image-wrap {
          flex: 1;
          min-height: 0;
          overflow: hidden;
          background: hsl(var(--muted));
        }

        .gallery-card__image {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 500ms cubic-bezier(0.25,0.46,0.45,0.94);
        }

        .gallery-card:hover .gallery-card__image {
          transform: scale(1.04);
        }

        .gallery-card__footer {
          flex-shrink: 0;
          background: hsl(var(--secondary));
          border-top: 1px solid hsl(var(--border));
          padding: 16px 20px 18px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .gallery-card--tall .gallery-card__footer {
          padding: 20px 24px 24px;
          gap: 8px;
        }

        .gallery-card__label {
          font-family: var(--font-heading);
          font-size: 10px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .gallery-card__name {
          font-family: var(--font-heading);
          font-size: clamp(18px, 2vw, 28px);
          font-weight: 300;
          font-style: italic;
          letter-spacing: 0.03em;
          line-height: 1.1;
          color: hsl(var(--primary));
          margin: 0;
        }

        .gallery-card--short .gallery-card__name {
          font-size: clamp(16px, 1.8vw, 22px);
        }

        .gallery-card__desc {
          font-family: var(--font-sans);
          font-size: 14px;
          font-weight: 400;
          color: hsl(var(--muted-foreground));
          line-height: 1.6;
          margin: 0;
          max-width: 38ch;
          display: none;
        }

        .gallery-card--tall .gallery-card__desc {
          display: block;
        }

        @media (max-width: 768px) {
          .gallery-grid-pair {
            display: flex;
            flex-direction: column;
            gap: 16px;
          }

          .gallery-card--tall .gallery-card__image-wrap {
            height: 320px;
          }

          .gallery-card--short .gallery-card__image-wrap {
            height: 220px;
          }

          .gallery-card--tall .gallery-card__desc {
            display: none;
          }
        }

        @media (max-width: 480px) {
          .gallery-card--tall .gallery-card__image-wrap {
            height: 260px;
          }

          .gallery-card--short .gallery-card__image-wrap {
            height: 180px;
          }
        }
      `}</style>
    </>
  );
}

interface GalleryItem {
  id: string;
  slot: string;
  label: string;
  name: string;
  desc: string | null;
  count: null;
  tall: boolean;
  pair: string;
  side: string;
}

function GalleryCard({ item }: { item: GalleryItem }) {
  return (
    <article className="gallery-card" aria-label={item.name}>
      <div className="gallery-card__image-wrap">
        <img
          className="gallery-card__image"
          src={item.slot}
          alt={`${item.name} nail art`}
          width={item.tall ? 800 : 700}
          height={item.tall ? 1100 : 500}
          loading={item.id === 'gel-ombre' ? 'eager' : 'lazy'}
        />
      </div>
      <div className="gallery-card__footer">
        <span className="gallery-card__label">{item.label}</span>
        <h2 className="gallery-card__name">{item.name}</h2>
        {item.desc && <p className="gallery-card__desc">{item.desc}</p>}
      </div>
    </article>
  );
}
