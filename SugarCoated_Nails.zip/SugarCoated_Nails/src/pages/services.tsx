import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

const ease = 'easeOut' as const;

// ─── Service data ────────────────────────────────────────────────────────────

const groups = [
  {
    id: 'manicure',
    label: 'Manicure',
    services: [
      {
        id: 'gel-manicure',
        eyebrow: 'Most Popular',
        name: 'Gel Manicure',
        format: 'lasts 2–3 weeks · removal included',
        price: '$55',
        featured: true,
        desc: 'A flawless, chip-free finish that holds up to your life. Includes shaping, cuticle care, and your choice of gel colour.',
      },
      {
        id: 'classic-manicure',
        eyebrow: 'Classic',
        name: 'Classic Polish Manicure',
        format: 'regular polish · same-day dry',
        price: '$35',
        featured: false,
        desc: null,
      },
      {
        id: 'gel-removal',
        eyebrow: 'Add-on',
        name: 'Gel Removal Only',
        format: 'safe soak-off · no damage',
        price: '$15',
        featured: false,
        desc: null,
      },
    ],
  },
  {
    id: 'nail-art',
    label: 'Nail Art',
    services: [
      {
        id: 'custom-nail-art',
        eyebrow: 'Signature',
        name: 'Custom Nail Art',
        format: 'hand-painted · fully bespoke',
        price: 'from $75',
        featured: true,
        desc: 'Bring your inspo or describe your vibe — florals, abstracts, ombré, gems, or something entirely your own. Priced by complexity.',
      },
      {
        id: 'nail-art-accent',
        eyebrow: 'Accent',
        name: 'Nail Art Accent (2 nails)',
        format: 'added to any service',
        price: '+$20',
        featured: false,
        desc: null,
      },
      {
        id: 'chrome-powder',
        eyebrow: 'Finish',
        name: 'Chrome Powder Finish',
        format: 'mirror or holographic',
        price: '+$15',
        featured: false,
        desc: null,
      },
      {
        id: 'rhinestones',
        eyebrow: 'Embellishment',
        name: 'Rhinestone & Gem Set',
        format: 'per nail or full set',
        price: 'from +$10',
        featured: false,
        desc: null,
      },
    ],
  },
  {
    id: 'pedicure',
    label: 'Pedicure',
    services: [
      {
        id: 'spa-pedicure',
        eyebrow: 'Treat Yourself',
        name: 'Spa Pedicure',
        format: 'soak · scrub · massage · polish',
        price: '$65',
        featured: true,
        desc: 'A full foot ritual — warm soak, exfoliation, callus care, a relaxing massage, and your choice of polish. The one to book when you need a reset.',
      },
      {
        id: 'gel-pedicure',
        eyebrow: 'Long-Lasting',
        name: 'Gel Pedicure',
        format: 'gel polish · lasts 3–4 weeks',
        price: '$75',
        featured: false,
        desc: null,
      },
      {
        id: 'mini-pedicure',
        eyebrow: 'Quick',
        name: 'Mini Pedicure',
        format: 'shape · tidy · polish',
        price: '$40',
        featured: false,
        desc: null,
      },
    ],
  },
];

// ─── Component ───────────────────────────────────────────────────────────────

export default function ServicesPage() {
  const site = 'https://sugarcoatednails.net';
  const title = 'Services & Pricing — SugarCoated Nails';
  const description =
    'Gel manicures, custom nail art, spa pedicures, and more. Transparent pricing for every service at SugarCoated Nails boutique.';
  const canonicalUrl = `${site}/services`;

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebPage',
          '@id': `${canonicalUrl}#webpage`,
          name: title,
          url: canonicalUrl,
          isPartOf: { '@id': `${site}/#website` },
          about: { '@id': `${site}/#organization` },
        })}</script>
      </Helmet>

      <main>
        <div className="sc-menu-page">

          {/* ── Page header ── */}
          <header className="sc-menu-header">
            <motion.span
              className="sc-eyebrow"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease }}
            >
              Services &amp; Pricing
            </motion.span>
            <h1 className="sc-menu-title" style={{ margin: 0 }}>
              <motion.span
                style={{ display: 'block' }}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, delay: 0.08, ease }}
              >
                The menu
              </motion.span>
            </h1>
            <motion.p
              className="sc-menu-standfirst"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.18, ease }}
            >
              Every service is done with care, never rushed. Prices are transparent — no surprises at checkout. Add-ons are listed exactly as they are: optional extras, not hidden fees.
            </motion.p>
          </header>

          {/* ── Service groups ── */}
          {groups.map((group, gi) => (
            <section
              key={group.id}
              className="sc-menu-group"
              aria-labelledby={`group-${group.id}`}
            >
              <motion.div
                className="sc-group-marker"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: gi * 0.05, ease }}
              >
                <span className="sc-group-eyebrow" id={`group-${group.id}`}>
                  {group.label}
                </span>
                <span className="sc-group-rule" aria-hidden="true" />
              </motion.div>

              <ul className="sc-menu-list" role="list">
                {group.services.map((svc, si) => (
                  <motion.li
                    key={svc.id}
                    initial={{ opacity: 0, y: 8 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.45, delay: si * 0.06, ease }}
                  >
                    <div className={`sc-menu-row${svc.featured ? ' sc-menu-row--featured' : ''}`}>
                      <div className="sc-row-name-block">
                        <span className="sc-row-eyebrow">{svc.eyebrow}</span>
                        <span className="sc-row-name">{svc.name}</span>
                        <span className="sc-row-format">{svc.format}</span>
                        {svc.desc && (
                          <p className="sc-row-desc">{svc.desc}</p>
                        )}
                      </div>
                      <span className="sc-row-price">{svc.price}</span>
                    </div>
                  </motion.li>
                ))}
              </ul>
            </section>
          ))}

          {/* ── Totals / bundle note ── */}
          <motion.div
            className="sc-menu-totals"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease }}
            role="complementary"
            aria-label="Booking note"
          >
            <div className="sc-totals-text">
              <span className="sc-eyebrow">Good to know</span>
              <p className="sc-totals-name">A few notes before you book</p>
              <ul className="sc-totals-notes">
                <li>A $20 deposit is required to hold your appointment — applied to your total.</li>
                <li>Cancellations within 24 hours may forfeit the deposit.</li>
                <li>Custom nail art quotes are confirmed at consultation — bring your inspo!</li>
                <li>All services include a complimentary hand or foot massage.</li>
              </ul>
            </div>
            <div className="sc-totals-cta">
              <Link to="/booking" className="sc-btn-primary">
                Book now
              </Link>
            </div>
          </motion.div>

          {/* ── Sky closing band ── */}
          <motion.section
            className="sc-menu-cta"
            aria-label="Ready to book"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease }}
          >
            <div className="sc-cta-text">
              <span className="sc-eyebrow" style={{ color: 'hsl(var(--muted-foreground))' }}>
                Not sure what to book?
              </span>
              <p className="sc-cta-headline">
                your nails, your way
              </p>
            </div>
            <Link to="/portfolio" className="sc-btn-ghost-sky">
              Browse the portfolio
            </Link>
          </motion.section>

        </div>
      </main>

      {/* ── Scoped styles ── */}
      <style>{`
        .sc-menu-page {
          max-width: 860px;
          margin: 0 auto;
          padding: 0 64px;
        }

        /* ── Page header ── */
        .sc-menu-header {
          padding-top: 88px;
          padding-bottom: 56px;
          border-bottom: 1.5px solid hsl(var(--primary));
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .sc-eyebrow {
          display: block;
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .sc-menu-title {
          font-family: var(--font-heading);
          font-size: clamp(44px, 5vw, 68px);
          font-weight: 300;
          letter-spacing: 0.04em;
          line-height: 1.0;
          color: hsl(var(--primary));
          margin: 0;
        }

        .sc-menu-standfirst {
          font-family: var(--font-sans);
          font-size: 16px;
          font-weight: 400;
          line-height: 1.65;
          color: hsl(var(--muted-foreground));
          max-width: 54ch;
          margin: 0;
        }

        /* ── Group ── */
        .sc-menu-group {
          padding-top: 56px;
        }

        .sc-group-marker {
          display: flex;
          align-items: center;
          gap: 20px;
          margin-bottom: 4px;
        }

        .sc-group-eyebrow {
          font-family: var(--font-heading);
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
          flex-shrink: 0;
        }

        .sc-group-rule {
          flex: 1;
          height: 1.5px;
          background: hsl(var(--primary));
          border-radius: 9999px;
        }

        /* ── Menu list ── */
        .sc-menu-list {
          list-style: none;
          margin: 0;
          padding: 0;
        }

        /* ── Menu row ── */
        .sc-menu-row {
          display: grid;
          grid-template-columns: 1fr auto;
          align-items: baseline;
          gap: 0 40px;
          padding: 26px 64px;
          margin: 0 -64px;
          background: transparent;
          transition: background 200ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
          cursor: default;
        }

        .sc-menu-row:hover {
          background: hsl(var(--secondary) / 0.18);
        }

        /* ── Name block ── */
        .sc-row-name-block {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .sc-row-eyebrow {
          font-family: var(--font-heading);
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: hsl(var(--muted-foreground));
          line-height: 1;
        }

        .sc-row-name {
          font-family: var(--font-sans);
          font-size: 17px;
          font-weight: 400;
          line-height: 1.3;
          color: hsl(var(--foreground));
        }

        .sc-row-format {
          font-family: var(--font-sans);
          font-size: 13px;
          font-weight: 400;
          color: hsl(var(--muted-foreground));
          letter-spacing: 0.01em;
          line-height: 1;
        }

        .sc-row-desc {
          font-family: var(--font-sans);
          font-size: 14px;
          font-weight: 400;
          line-height: 1.6;
          color: hsl(var(--muted-foreground));
          max-width: 52ch;
          margin: 6px 0 0;
          display: none;
        }

        /* ── Price ── */
        .sc-row-price {
          font-family: var(--font-heading);
          font-size: 18px;
          font-weight: 400;
          letter-spacing: 0.02em;
          color: hsl(var(--primary));
          white-space: nowrap;
          align-self: center;
        }

        /* ── Featured row ── */
        .sc-menu-row--featured .sc-row-name {
          font-family: var(--font-heading);
          font-style: italic;
          font-weight: 300;
          font-size: clamp(22px, 2.2vw, 28px);
          letter-spacing: 0.03em;
          line-height: 1.1;
          color: hsl(var(--primary));
        }

        .sc-menu-row--featured .sc-row-desc {
          display: block;
        }

        .sc-menu-row--featured .sc-row-price {
          align-self: start;
          padding-top: 4px;
        }

        /* ── Totals ── */
        .sc-menu-totals {
          margin-top: 56px;
          padding-top: 36px;
          border-top: 1.5px solid hsl(var(--primary));
          padding-bottom: 80px;
          display: grid;
          grid-template-columns: 1fr auto;
          align-items: start;
          gap: 0 48px;
        }

        .sc-totals-text {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .sc-totals-name {
          font-family: var(--font-heading);
          font-style: italic;
          font-weight: 300;
          font-size: clamp(26px, 3vw, 38px);
          letter-spacing: 0.03em;
          line-height: 1.1;
          color: hsl(var(--primary));
          margin: 0;
        }

        .sc-totals-notes {
          list-style: none;
          margin: 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .sc-totals-notes li {
          font-family: var(--font-sans);
          font-size: 14px;
          font-weight: 400;
          line-height: 1.6;
          color: hsl(var(--muted-foreground));
          padding-left: 16px;
          position: relative;
        }

        .sc-totals-notes li::before {
          content: '—';
          position: absolute;
          left: 0;
          color: hsl(var(--primary));
          font-family: var(--font-heading);
        }

        .sc-totals-cta {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 8px;
          padding-top: 8px;
        }

        /* ── Buttons ── */
        .sc-btn-primary {
          display: inline-flex;
          align-items: center;
          padding: 14px 36px;
          background: hsl(var(--primary));
          color: hsl(var(--primary-foreground));
          font-family: var(--font-heading);
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-decoration: none;
          border-radius: 9999px;
          box-shadow: 0 4px 20px rgba(155,111,190,0.25);
          transition: transform 200ms cubic-bezier(0.25,0.46,0.45,0.94),
                      box-shadow 200ms cubic-bezier(0.25,0.46,0.45,0.94);
          white-space: nowrap;
        }

        .sc-btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 28px rgba(155,111,190,0.38);
        }

        /* ── Sky closing band ── */
        .sc-menu-cta {
          background: hsl(var(--accent));
          border-top: 1.5px solid hsl(var(--primary));
          margin: 0 -64px;
          padding: 72px 64px 88px;
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 48px;
        }

        .sc-cta-text {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .sc-cta-headline {
          font-family: var(--font-heading);
          font-size: clamp(28px, 3vw, 44px);
          font-weight: 300;
          font-style: italic;
          letter-spacing: 0.03em;
          line-height: 1.1;
          color: hsl(var(--primary));
          max-width: 20ch;
          margin: 0;
        }

        .sc-btn-ghost-sky {
          display: inline-flex;
          align-items: center;
          flex-shrink: 0;
          padding: 12px 28px;
          background: transparent;
          color: hsl(var(--primary));
          font-family: var(--font-heading);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          text-decoration: none;
          border: 1.5px solid hsl(var(--primary));
          border-radius: 9999px;
          align-self: flex-end;
          transition: background 200ms cubic-bezier(0.25,0.46,0.45,0.94),
                      color 200ms cubic-bezier(0.25,0.46,0.45,0.94);
          white-space: nowrap;
        }

        .sc-btn-ghost-sky:hover {
          background: hsl(var(--primary));
          color: hsl(var(--primary-foreground));
        }

        /* ── Responsive ── */
        @media (max-width: 720px) {
          .sc-menu-page {
            padding-left: 24px;
            padding-right: 24px;
          }

          .sc-menu-header {
            padding-top: 56px;
            padding-bottom: 40px;
          }

          .sc-menu-group {
            padding-top: 40px;
          }

          .sc-menu-row {
            padding-left: 24px;
            padding-right: 24px;
            margin-left: -24px;
            margin-right: -24px;
            gap: 0 20px;
            padding-top: 20px;
            padding-bottom: 20px;
          }

          .sc-menu-row--featured .sc-row-desc {
            display: none;
          }

          .sc-menu-totals {
            grid-template-columns: 1fr;
            gap: 28px 0;
            padding-bottom: 56px;
          }

          .sc-totals-cta {
            align-items: flex-start;
          }

          .sc-menu-cta {
            margin: 0 -24px;
            padding: 56px 24px 72px;
            flex-direction: column;
            align-items: flex-start;
            gap: 28px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .sc-menu-row { transition: none; }
        }
      `}</style>
    </>
  );
}
