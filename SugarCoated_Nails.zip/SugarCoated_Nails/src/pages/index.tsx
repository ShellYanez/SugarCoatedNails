import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

const ease = [0.25, 0.46, 0.45, 0.94] as const;

export default function HomePage() {
  return (
    <>
      <Helmet>
        <title>SugarCoated Nails — Nail Boutique | Coming Soon</title>
        <meta
          name="description"
          content="SugarCoated Nails is a nail boutique offering custom nail art, gel manicures, and appointment booking. Opening soon — follow along for updates."
        />
        <meta property="og:title" content="SugarCoated Nails — Coming Soon" />
        <meta
          property="og:description"
          content="Custom nail art, gel manicures, and a whole lot of love. Opening soon."
        />
        <meta property="og:type" content="website" />
        <link rel="canonical" href="https://sugarcoatednails.net/" />
      </Helmet>

      {/* Full-viewport coming soon page */}
      <main
        style={{
          minHeight: 'calc(100vh - 72px)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'hsl(var(--background))',
          padding: '80px 32px',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* Decorative background blobs */}
        <div
          aria-hidden="true"
          style={{
            position: 'absolute',
            top: '-80px',
            right: '-120px',
            width: '480px',
            height: '480px',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(135,206,235,0.18) 0%, transparent 70%)',
            pointerEvents: 'none',
          }}
        />
        <div
          aria-hidden="true"
          style={{
            position: 'absolute',
            bottom: '-60px',
            left: '-100px',
            width: '400px',
            height: '400px',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(155,111,190,0.10) 0%, transparent 70%)',
            pointerEvents: 'none',
          }}
        />

        {/* Text content */}
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '20px',
            textAlign: 'center',
            maxWidth: '560px',
          }}
        >
          {/* Eyebrow label */}
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15, ease }}
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: '12px',
              fontWeight: 500,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: 'hsl(var(--accent))',
              margin: 0,
            }}
          >
            Something beautiful is on its way
          </motion.p>

          {/* Main heading */}
          <h1 style={{ margin: 0, padding: 0 }}>
            <motion.span
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.25, ease }}
              style={{
                display: 'block',
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(36px, 6vw, 64px)',
                fontWeight: 300,
                letterSpacing: '0.05em',
                color: 'hsl(var(--primary))',
                lineHeight: 1.15,
              }}
            >
              SugarCoated Nails
            </motion.span>
          </h1>

          {/* Divider */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.5, delay: 0.38, ease }}
            style={{
              width: '48px',
              height: '1.5px',
              background: 'hsl(var(--primary))',
              borderRadius: '9999px',
              transformOrigin: 'center',
            }}
          />

          {/* Body copy */}
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.45, ease }}
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: '17px',
              fontWeight: 400,
              color: 'hsl(var(--muted-foreground))',
              lineHeight: 1.7,
              margin: 0,
            }}
          >
            Your new favorite nail boutique is almost here — custom nail art, gel manicures, and a whole lot of love. We're putting the finishing touches on something special.
          </motion.p>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.55, ease }}
            style={{ marginTop: '12px' }}
          >
            <Link
              to="/booking"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '14px 36px',
                background: 'hsl(var(--primary))',
                color: 'hsl(var(--primary-foreground))',
                fontFamily: 'var(--font-heading)',
                fontSize: '13px',
                fontWeight: 600,
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                textDecoration: 'none',
                borderRadius: '9999px',
                boxShadow: '0 4px 24px rgba(155,111,190,0.25)',
                transition: 'transform 200ms cubic-bezier(0.25,0.46,0.45,0.94), box-shadow 200ms cubic-bezier(0.25,0.46,0.45,0.94)',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-2px)';
                (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 8px 32px rgba(155,111,190,0.38)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(0)';
                (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 4px 24px rgba(155,111,190,0.25)';
              }}
            >
              Get notified when we open
            </Link>
          </motion.div>

          {/* Social nudge */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.7, ease }}
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: '13px',
              color: 'hsl(var(--muted-foreground))',
              margin: 0,
              marginTop: '4px',
            }}
          >
            Follow us on{' '}
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                color: 'hsl(var(--primary))',
                textDecoration: 'underline',
                textUnderlineOffset: '3px',
                fontWeight: 500,
              }}
            >
              Instagram
            </a>{' '}
            for sneak peeks
          </motion.p>
        </div>
      </main>
    </>
  );
}
